import React from 'react';
import './App.css';
import { Routes,Route } from "react-router-dom";
import Contact from './Routerpractice/Contact';
import About from './Routerpractice/About';
import Home from './Routerpractice/Home';

function App() {
  return (
   <>
   <div>
   <Routes>
<Route path ='/contact' element={<Contact/>}/>
<Route path ='/about' element={<About/>}/>
<Route exact path ='/' element={<Home/>}/>
     </Routes>
        </div>
   </>
  );
}

export default App;
