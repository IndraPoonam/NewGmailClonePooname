// import Container from "./Container";
// import Header from "./Header";
// import  Leftside from "./Leftside";
// import Mail from "./Mail";


function Main (){
    return (

        <div>
     {/* <Routes>
<Route path ='/contact' element={<Contact/>}/>
<Route path ='/about' element={<About/>}/>
<Route path ='/home' element={<Home/>}/>
     </Routes> */}
        </div>
        
        
/* <div class="body-wrapper">
<Leftside/>
<Header/>
<Mail/>
<Container/>
</div> */
    )
};
export default Main;