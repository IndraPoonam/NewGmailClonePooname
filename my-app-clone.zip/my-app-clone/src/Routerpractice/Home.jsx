import React from 'react';

function Home() {
  return (
    <div>Tell me your Home Adress</div>
  )
}

export default Home