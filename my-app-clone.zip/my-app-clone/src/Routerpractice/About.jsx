import React from 'react';

function About() {
  return (
    <div>Tell me About yourself</div>
  )
}

export default About